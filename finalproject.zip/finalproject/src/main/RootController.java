package main;

import java.net.URL;
import java.util.ResourceBundle;

import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.text.Text;
import javafx.scene.*;

public class RootController implements Initializable {
	main t_main = new main();
	Player player = new Player();
	Player dealer = new Player();
	Card[] cards = t_main.cardinit();
	String backcard_imagepath = "image/back.png";
	
	boolean p_stay=false;
	boolean d_stay=false;
	
	@FXML private Button hit_b;
	@FXML private Button stay_b;
	@FXML private Text texting;
	
	@FXML private ImageView[] p_hand = new ImageView[6];
	@FXML private ImageView p_hand1;
	@FXML private ImageView p_hand2;
	@FXML private ImageView p_hand3;
	@FXML private ImageView p_hand4;
	@FXML private ImageView p_hand5;
	@FXML private ImageView p_hand6;
	@FXML private ImageView[] d_hand = new ImageView[6];
	@FXML private ImageView d_hand1;
	@FXML private ImageView d_hand2;
	@FXML private ImageView d_hand3;
	@FXML private ImageView d_hand4;
	@FXML private ImageView d_hand5;
	@FXML private ImageView d_hand6;

	@Override
	public void initialize(URL location, ResourceBundle resources) {
		p_hand[0] = p_hand1;
		p_hand[1] = p_hand2;
		p_hand[2] = p_hand3;
		p_hand[3] = p_hand4;
		p_hand[4] = p_hand5;
		p_hand[5] = p_hand6;
		//----------------------
		d_hand[0] = d_hand1;
		d_hand[1] = d_hand2;
		d_hand[2] = d_hand3;
		d_hand[3] = d_hand4;
		d_hand[4] = d_hand5;
		d_hand[5] = d_hand6;
		
		game_init();
	}
	
	private void game_init() {
		hit_b.setOnAction(event->handle_hit_b_Action(event));
		hit_b.setText("Hit");
		stay_b.setOnAction(event->handle_stay_b_Action(event));
		stay_b.setDisable(false);
		
		d_stay = false;
		p_stay = false;
		t_main.anti_dupli.clear();
		player.clear();
		dealer.clear();
		texting.setText("BLACK JACK GAME");
		
		for(int i=0;i<6;i++) {
			p_hand[i].setImage(null);
			d_hand[i].setImage(null);
		}
	}
	
	private void dealer_showdown() {
		for(int i=0;i<dealer.mount_of_hand();i++) {
			String path = "image/"+dealer.getHand().get(i).getStripe()+"/"+dealer.getHand().get(i).getStripe()+dealer.getHand().get(i).getName()+".png";
			d_hand[i].setImage(new Image(path));
		}
	}
	
	public void handle_hit_b_Action(ActionEvent event) { 
		int t_total=dealer.gettotal();
		String path;
		t_main.givecard(player, cards);
		path = "image/"+player.getHand().get(player.mount_of_hand()-1).getStripe()+"/"+player.getHand().get(player.mount_of_hand()-1).getStripe()+player.getHand().get(player.mount_of_hand()-1).getName()+".png";
		texting.setText("�÷��̾� : "+player.gettotal());
		p_hand[player.mount_of_hand()-1].setImage(new Image(path));
		if(player.isbust()) {
			texting.setText("�÷��̾� ����Ʈ");
			d_stay = true;
			p_stay = true;
			hit_b_to_restart();
			dealer_showdown();
			return;
		}
		
		dealer_action();
		if(dealer.mount_of_hand() == 6 || player.mount_of_hand() ==6) {
			d_stay = true;
			p_stay = true;
			hit_b_to_restart();
			dealer_showdown();
			totalcompare();
		}
	}
	
	public void hit_b_to_restart() {
		hit_b.setOnAction(event->handle_restart_b_Action(event));
		hit_b.setText("Restart");
		stay_b.setDisable(true);
	}
	
	public void handle_stay_b_Action(ActionEvent event) { 
		p_stay=true;
		while(!d_stay) dealer_action();
		dealer_showdown();
		if(d_stay && p_stay && !dealer.isbust() && !player.isbust()) {
			totalcompare();
		}
		hit_b_to_restart();
	}
	
	public void handle_restart_b_Action(ActionEvent event) { 
		game_init();
	}
	
	public void dealer_action() {
		if(!d_stay) {
			if(ai_h_or_s(dealer.gettotal())) {
				t_main.givecard(dealer, cards); 
				String path = "image/back.png";
				d_hand[dealer.mount_of_hand()-1].setImage(new Image(path));
			}
			else d_stay = true;
		}
		else d_stay=true;
		if(dealer.isbust()) {
			texting.setText("���� ����Ʈ");
			p_stay=true;
			d_stay=true;
			hit_b_to_restart();
			dealer_showdown();
		}
	}
	
	public void totalcompare() {
		if(dealer.gettotal() > player.gettotal()) {
			texting.setText("���� �¸�");
		} else if(dealer.gettotal() == player.gettotal()) {
			texting.setText("���º�");
		} else {
			texting.setText("�÷��̾� �¸�");
		}
	}
	
	public boolean ai_h_or_s(int total) {
		
		int percentage=0;
		if(total <= 11) percentage = 100;
		else if (total == 12)	percentage = 95;
		else if (total == 13)	percentage = 80;
		else if (total == 14)	percentage = 75;
		else if (total == 15)	percentage = 50;
		else if (total == 16)	percentage = 25;
		else if (total == 17)	percentage = 15;
		else if (total == 18)	percentage = 10;
		else return false;
		if((int)(Math.random()*100)+1 <= percentage) return true;
		else return false;
	}

}
