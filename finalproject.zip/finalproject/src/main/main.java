package main;

import java.util.*;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

import java.lang.*;

public class main extends Application {
	
	Stack<Integer> anti_dupli = new Stack();

	@Override
	public void start(Stage primaryStage) throws Exception {
		Parent root = FXMLLoader.load(getClass().getResource("root.fxml"));
		Scene scene = new Scene(root);
		
		primaryStage.setTitle("main");
		primaryStage.setScene(scene);
		primaryStage.show();
	}
	
	public static void main(String[] args) {
		launch(args);
	}
	
	
	
/*
	public static void main(String[] args) {
		main d_main = new main();
		
		Player player = new Player();
		Player dealer = new Player();
		Card[] cards = d_main.cardinit();
				
		//for(Card c : cards) c.info();
		//d_main.givecard(player, cards);
		//player.info();
		while(true){
			//Start Menu
			//First Deal
			d_main.givecard(player, cards);
			d_main.givecard(player, cards);
			d_main.givecard(dealer, cards);
			d_main.givecard(dealer, cards);
			d_main.givecard(player, cards);
			
			break;
			//Free Deal
			/*for(int i=0;i<4; i++){
				
			}
			//result
		}
		player.info();
		
	}*/
	
	public Card[] cardinit() {
		Card cards[] = new Card[52];
		String[] sTemp = {"Spade","Club","Dia","Heart"};
		int i=0;
		for(int t=0;t<4;t++)
		{
			cards[i++] = new Card("A",sTemp[t]);
			for(int k=2;k<=10;k++){
				cards[i++] = new Card(Integer.toString(k),sTemp[t]);
			}
			
			cards[i++] = new Card("J",sTemp[t]);
			cards[i++] = new Card("Q",sTemp[t]);
			cards[i++] = new Card("K",sTemp[t]);
		}
		return cards;
	}
	
	public void givecard (Player p, Card card[]){
		Random random = new Random(System.currentTimeMillis());
		int r;
		while(true){
			r = random.nextInt(52);
			if(!this.anti_dupli.contains(r)) {
				this.anti_dupli.push(r);
				p.add(card[r]);
				return;
			}
		}
		
	}

}
