package main;

public class Card {
	private int value;
	private String name;
	private String stripe;
	
	Card(String name, String stripe)
	{
		this.name = name;
		this.stripe = stripe;
		char temp = name.charAt(name.length()-1);
		if(temp >= '2' && temp <= '9') this.value = temp-'0';
		else if (temp == '0') this.value = 10;
		else if (temp == 'K') this.value = 10;
		else if (temp == 'Q') this.value = 10;
		else if (temp == 'J') this.value = 10;
		else if (temp == 'A') this.value = 11;
		else System.out.println("�Է¿���");
	}
	
	public void info() {
		System.out.println(value + " " + name + " " + stripe);
	}
	
	public int getValue() {
		return value;
	}
	
	public String getName() {
		return name;
	}
	
	public String getStripe() {
		return stripe;
	}
	
	public boolean setAto1() {
		if(this.name == "A") {
			this.value = 1;
			return true;
		} else {
			return false;
		}
	}
}
