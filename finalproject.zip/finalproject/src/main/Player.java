package main;

import java.util.*;
public class Player {
	private List<Card> hand = new ArrayList<Card>();
	private int total=0;
	
	Player(){}
	
	public void add(Card t_card){
		int i=0;
		hand.add(t_card);
		totalinit();
		for(i=0;i<hand.size();i++){
			if(total>21){ hand.get(i).setAto1(); totalinit();}
		}
	}
	private void totalinit() {
		total=0;
		for(Card c : hand){
			total += c.getValue();
		}
	}
	
	public int mount_of_hand() {
		return hand.size();
	}
	
	public List<Card> getHand() {
		return hand;
	}
	
	public void info() {
		hand.forEach((c)->{c.info();});
		System.out.print(total);
		if(!this.isbust()) {
			System.out.println(" ��");
		} else {
			System.out.println(" ����Ʈ");
		}
	}
	
	public void clear() {
		hand.clear();
		total = 0;
	}
	
	public boolean isbust() {
		if(total > 21){
			return true;
		} else
			return false;
	}
	
	public int gettotal() {
		return total;
	}
}
